<?php
session_start();

$host     = "localhost";
$port     = "5432";
$dbname   = "diki"; 
$user     = "postgres"; 
$password = "admin123";

try {
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}



// ----------------------------------------------------
// AJAX HANDLERS
// ----------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'save_polygon') {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    $geojson = $input['geojson'] ?? null;
    
    if (!$geojson) {
        echo json_encode(['status' => 'error', 'message' => 'Geometri tidak valid']);
        exit;
    }

    $stmt_count = $pdo->query("SELECT COUNT(*) FROM lokasi2 WHERE ST_GeometryType(geom) != 'ST_Point'");
    $count = (int)$stmt_count->fetchColumn();
    $nama = 'area ' . ($count + 1);

    $query = "INSERT INTO lokasi2 (nama, geom) VALUES (:nama, ST_SetSRID(ST_GeomFromGeoJSON(:geojson), 4326))";
    $stmt = $pdo->prepare($query);
    $res = $stmt->execute([
        ':nama' => $nama,
        ':geojson' => json_encode($geojson)
    ]);
    
    if ($res) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan']);
    }
    exit;
}

// Delete Polygon Handler
if (isset($_GET['action']) && $_GET['action'] === 'delete_polygon' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM lokasi2 WHERE id = :id");
    $stmt->execute(['id' => $id]);
    header("Location: index.php?tab=spasial");
    exit;
}

// ----------------------------------------------------
// DATA FETCHING FOR TAB 1: SPATIAL OVERLAY
// ----------------------------------------------------
// All user-drawn polygons
$polygons = $pdo->query("SELECT id, nama FROM lokasi2 WHERE ST_GeometryType(geom) != 'ST_Point' ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Selected areas for overlay
$id_a = isset($_GET['id_a']) ? (int)$_GET['id_a'] : 0;
$id_b = isset($_GET['id_b']) ? (int)$_GET['id_b'] : 0;

if ($id_a <= 0 || $id_b <= 0) {
    // Try to get area 1 and area 2 defaults
    $def_a = (int)$pdo->query("SELECT id FROM lokasi2 WHERE nama = 'area 1' LIMIT 1")->fetchColumn();
    $def_b = (int)$pdo->query("SELECT id FROM lokasi2 WHERE nama = 'area 2' LIMIT 1")->fetchColumn();

    if ($def_a <= 0 && count($polygons) > 0) $def_a = $polygons[0]['id'];
    if ($def_b <= 0 && count($polygons) > 1) $def_b = $polygons[1]['id'];
    else if ($def_b <= 0 && count($polygons) > 0) $def_b = $polygons[0]['id'];

    if ($id_a <= 0) $id_a = $def_a;
    if ($id_b <= 0) $id_b = $def_b;
}

// Fetch polygon geometries
$stmt_wA = $pdo->prepare("SELECT ST_AsGeoJSON(geom) FROM lokasi2 WHERE id = :id");
$stmt_wA->execute(['id' => $id_a]);
$geojson_wA = $stmt_wA->fetchColumn() ?: 'null';

$stmt_wB = $pdo->prepare("SELECT ST_AsGeoJSON(geom) FROM lokasi2 WHERE id = :id");
$stmt_wB->execute(['id' => $id_b]);
$geojson_wB = $stmt_wB->fetchColumn() ?: 'null';

// Fetch all schools created by admin (for the checkboxes)
$list_sekolah_admin = $pdo->query("SELECT id, nama_sekolah, jenjang FROM sekolah ORDER BY nama_sekolah ASC")->fetchAll(PDO::FETCH_ASSOC);

// Selected schools for analysis
$selected_school_ids = isset($_GET['selected_schools']) ? array_map('intval', $_GET['selected_schools']) : [];
if (empty($selected_school_ids) && !empty($list_sekolah_admin)) {
    // Default to all schools if none selected
    $selected_school_ids = array_column($list_sekolah_admin, 'id');
}

// Fetch all locations to display on Main Map (excluding point markers)
$all_drawn_polygons = $pdo->query("SELECT id, nama, ST_AsGeoJSON(geom) AS geom_json FROM lokasi2 WHERE ST_GeometryType(geom) != 'ST_Point' ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$all_polys_data = [];
foreach ($all_drawn_polygons as $row) {
    $all_polys_data[] = [
        'id' => (int)$row['id'],
        'nama' => $row['nama'],
        'geojson' => json_decode($row['geom_json'])
    ];
}

// Fetch checked schools geometries to show on main map
$list_selected_sekolah = [];
if (!empty($selected_school_ids)) {
    $placeholders = implode(',', array_fill(0, count($selected_school_ids), '?'));
    $stmt_sel = $pdo->prepare("SELECT id, nama_sekolah, jenjang, ST_X(geom) as lng, ST_Y(geom) as lat FROM sekolah WHERE id IN ($placeholders)");
    $stmt_sel->execute($selected_school_ids);
    $list_selected_sekolah = $stmt_sel->fetchAll(PDO::FETCH_ASSOC);
}

// Spatial computation helper
function get_spatial_data($pdo, $id_a, $id_b, $geom_expr, $school_ids = []) {
    if ($id_a <= 0 || $id_b <= 0) {
        return ['geometry' => null, 'markers' => []];
    }
    
    // Get geom
    $q_geom = "SELECT ST_AsGeoJSON($geom_expr) FROM lokasi2 a, lokasi2 b WHERE a.id = :id_a AND b.id = :id_b";
    $stmt = $pdo->prepare($q_geom);
    $stmt->execute(['id_a' => $id_a, 'id_b' => $id_b]);
    $geojson = $stmt->fetchColumn() ?: null;
    
    // Get selected school markers within geometry
    $markers = [];
    if (!empty($school_ids)) {
        $placeholders = implode(',', array_fill(0, count($school_ids), '?'));
        $q_markers = "
            SELECT s.nama_sekolah AS nama, ST_AsGeoJSON(s.geom) AS geom_json
            FROM sekolah s, lokasi2 a, lokasi2 b
            WHERE a.id = ? AND b.id = ?
              AND s.id IN ($placeholders)
              AND ST_Within(s.geom, $geom_expr)
        ";
        
        $params = array_merge([$id_a, $id_b], $school_ids);
        $stmt_m = $pdo->prepare($q_markers);
        $stmt_m->execute($params);
        while ($row = $stmt_m->fetch(PDO::FETCH_ASSOC)) {
            $markers[] = [
                'nama' => $row['nama'],
                'geojson' => json_decode($row['geom_json'])
            ];
        }
    }
    
    return [
        'geometry' => $geojson ? json_decode($geojson) : null,
        'markers' => $markers
    ];
}

$data_only_a = get_spatial_data($pdo, $id_a, $id_b, "a.geom", $selected_school_ids);
$data_only_b = get_spatial_data($pdo, $id_a, $id_b, "b.geom", $selected_school_ids);
$data_union = get_spatial_data($pdo, $id_a, $id_b, "ST_Union(a.geom, b.geom)", $selected_school_ids);
$data_diff_ab = get_spatial_data($pdo, $id_a, $id_b, "ST_Difference(a.geom, b.geom)", $selected_school_ids);
$data_diff_ba = get_spatial_data($pdo, $id_a, $id_b, "ST_Difference(b.geom, a.geom)", $selected_school_ids);
$data_outside = get_spatial_data($pdo, $id_a, $id_b, "ST_Difference(ST_SetSRID(ST_MakeEnvelope(-180, -90, 180, 90), 4326), ST_Union(a.geom, b.geom))", $selected_school_ids);
$data_intersect = get_spatial_data($pdo, $id_a, $id_b, "ST_Intersection(a.geom, b.geom)", $selected_school_ids);



?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Geografis Sekolah</title>
    
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>

    <style>
        .polygon-tooltip {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: bold;
            color: #1e293b;
        }
        .custom-school-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
            color: white;
            font-size: 9px;
            font-weight: bold;
        }
        .leaflet-container { background: #f8fafc; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased">

    <div class="max-w-7xl mx-auto px-4 py-8 space-y-6">
        
        <!-- HEADER / NAVIGATION -->
        <header class="flex flex-col md:flex-row items-center justify-between border-b border-slate-200 pb-5 gap-4">
            <div>
                <h1 class="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                    <i class="fa-solid fa-map-location-dot text-indigo-600"></i> SIG Pemetaan & Analisis Sekolah
                </h1>
                <p class="text-sm text-slate-500 mt-1">Sistem informasi pemetaan spasial dan overlay spasial</p>
            </div>
            
            <div class="flex items-center gap-4">


                <a href="admin.php" class="text-xs font-bold px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl shadow-sm active:scale-[0.98] transition-all">
                    <i class="fa-solid fa-lock mr-1.5"></i> Portal Admin
                </a>
            </div>
        </header>

        <!-- ========================================== -->
        <!-- TAB 1: SPATIAL OVERLAY ANALYSIS (6 MAPS) -->
        <!-- ========================================== -->

            <div class="space-y-8">
                <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                    
                    <!-- Sidebar Controls (Left column) -->
                    <div class="lg:col-span-1 space-y-6">
                        <div class="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
                            <h3 class="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                                <i class="fa-solid fa-sliders text-indigo-500"></i> Wilayah Analisis
                            </h3>
                            
                            <form method="GET" action="index.php" class="space-y-4">
                                <input type="hidden" name="tab" value="spasial">

                                <div class="space-y-1.5">
                                    <label for="id_a" class="text-xs font-medium text-slate-600">Wilayah A</label>
                                    <select name="id_a" id="id_a" class="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all" onchange="this.form.submit()">
                                        <?php if (empty($polygons)): ?>
                                            <option value="0">-- Gambar area dulu --</option>
                                        <?php else: ?>
                                            <?php foreach ($polygons as $poly): ?>
                                                <option value="<?php echo $poly['id']; ?>" <?php echo $poly['id'] == $id_a ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($poly['nama']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                                <div class="space-y-1.5">
                                    <label for="id_b" class="text-xs font-medium text-slate-600">Wilayah B</label>
                                    <select name="id_b" id="id_b" class="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all" onchange="this.form.submit()">
                                        <?php if (empty($polygons)): ?>
                                            <option value="0">-- Gambar area dulu --</option>
                                        <?php else: ?>
                                            <?php foreach ($polygons as $poly): ?>
                                                <option value="<?php echo $poly['id']; ?>" <?php echo $poly['id'] == $id_b ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($poly['nama']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="space-y-1.5 pt-2 border-t border-slate-100">
                                    <label class="text-xs font-bold text-slate-600 uppercase tracking-wider block">Pilih Sekolah Admin</label>
                                    <div class="relative" id="school-dropdown-container">
                                        <button type="button" id="school-dropdown-btn" class="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-700 flex justify-between items-center hover:bg-slate-100 transition-colors focus:ring-2 focus:ring-indigo-500 cursor-pointer">
                                            <span class="truncate font-medium text-slate-700" id="school-dropdown-text">
                                                <?php 
                                                if (empty($selected_school_ids) || count($selected_school_ids) === count($list_sekolah_admin)) {
                                                    echo "Semua Sekolah Admin";
                                                } else {
                                                    echo count($selected_school_ids) . " Sekolah Terpilih";
                                                }
                                                ?>
                                            </span>
                                            <i class="fa-solid fa-chevron-down text-slate-400 text-xs transition-transform" id="school-dropdown-arrow"></i>
                                        </button>
                                        <div id="school-dropdown-menu" class="hidden absolute left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-lg shadow-lg z-[1000] p-2.5 max-h-60 overflow-y-auto space-y-1.5">
                                            <?php if (empty($list_sekolah_admin)): ?>
                                                <p class="text-xs text-slate-400 py-1 text-center">Belum ada sekolah dari admin.</p>
                                            <?php else: ?>
                                                <?php foreach ($list_sekolah_admin as $sch): ?>
                                                    <label class="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer hover:text-indigo-600 p-1.5 rounded hover:bg-slate-50 transition-colors">
                                                        <input type="checkbox" name="selected_schools[]" value="<?php echo $sch['id']; ?>" 
                                                               <?php echo in_array($sch['id'], $selected_school_ids) ? 'checked' : ''; ?>
                                                               class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                                                               onchange="this.form.submit()">
                                                        <span class="truncate"><?php echo htmlspecialchars($sch['nama_sekolah']); ?> (<?php echo $sch['jenjang']; ?>)</span>
                                                    </label>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <small class="text-[10px] text-slate-400 block mt-1">*Jika tidak ada yang dipilih, semua sekolah admin akan dianalisis.</small>
                                </div>
                            </form>
                        </div>

                        <!-- User Polygons list manager -->
                        <div class="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
                            <h3 class="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                                <i class="fa-solid fa-shapes text-emerald-500"></i> Poligon Digambar
                            </h3>
                            <div class="max-h-[200px] overflow-y-auto pr-1 space-y-2 divide-y divide-slate-100 text-xs">
                                <?php if (empty($polygons)): ?>
                                    <p class="text-slate-400 py-1 italic">Tidak ada poligon buatan Anda.</p>
                                <?php else: ?>
                                    <?php foreach ($polygons as $poly): ?>
                                        <div class="flex items-center justify-between py-1.5 first:pt-0">
                                            <span class="font-medium text-slate-700"><i class="fa-solid fa-draw-polygon text-slate-400 mr-1.5"></i> <?php echo htmlspecialchars($poly['nama']); ?></span>
                                            <a href="index.php?action=delete_polygon&id=<?php echo $poly['id']; ?>" 
                                               class="text-rose-500 hover:text-rose-600 p-1 rounded hover:bg-rose-50 transition-colors"
                                               onclick="return confirm('Hapus poligon ini?')">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </a>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Main Map (Right column) -->
                    <div class="lg:col-span-3">
                        <div class="bg-white rounded-xl border border-slate-200 p-2 shadow-sm">
                            <div class="h-[480px] w-full rounded-lg overflow-hidden border border-slate-100" id="mapbesar"></div>
                        </div>
                    </div>
                </div>

                <!-- Sub-Maps Section (Union, Diff, etc.) -->
                <div class="relative py-4">
                    <div class="absolute inset-0 flex items-center" aria-hidden="true">
                        <div class="w-full border-t border-slate-200"></div>
                    </div>
                    <div class="relative flex justify-start">
                        <span class="bg-slate-50 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                            <i class="fa-solid fa-chart-pie text-indigo-500"></i> Hasil Operasi Spasial Overlay
                        </span>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-indigo-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">1. Wilayah A saja</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-only-a"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-emerald-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">2. Wilayah B saja</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-only-b"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-purple-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">3. Wilayah A dan B (Union)</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-union"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-blue-600"></span>
                            <h4 class="text-sm font-semibold text-slate-800">4. Wilayah A tapi bukan B</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-diff-ab"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-rose-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">5. Wilayah B tapi bukan A</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-diff-ba"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-cyan-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">6. Selain Wilayah A dan B</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-outside"></div>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col space-y-3 md:col-span-2 lg:col-span-3">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-slate-500"></span>
                            <h4 class="text-sm font-semibold text-slate-800">7. Irisan A dan B (Intersection)</h4>
                        </div>
                        <div class="h-64 w-full rounded-lg overflow-hidden border border-slate-100" id="sub-map-intersect"></div>
                    </div>
                </div>
            </div>



    </div>

    <!-- ========================================== -->
    <!-- JAVASCRIPT LOGIC -->
    <!-- ========================================== -->
    <script>
        // Colors mapping for school pins
        function getSchoolColor(jenjang) {
            if (jenjang === 'SD') return '#3b82f6'; // Blue
            if (jenjang === 'SMP') return '#f59e0b'; // Orange/Amber
            return '#10b981'; // Green (SMA)
        }

        function getSchoolIcon(jenjang) {
            const color = getSchoolColor(jenjang);
            return L.divIcon({
                className: '',
                html: `<div class="custom-school-icon" style="background-color: ${color};"><i class="fa-solid fa-graduation-cap text-[8px]"></i></div>`,
                iconSize: [22, 22],
                iconAnchor: [11, 11],
                popupAnchor: [0, -11]
            });
        }


            // Data values from PHP
            const semuaPolygons = <?php echo json_encode($all_polys_data); ?>;
            const selectedSchools = <?php echo json_encode($list_selected_sekolah); ?>;
            const dataOnlyA = <?php echo json_encode($data_only_a); ?>;
            const dataOnlyB = <?php echo json_encode($data_only_b); ?>;
            const dataUnion = <?php echo json_encode($data_union); ?>;
            const dataDiffAB = <?php echo json_encode($data_diff_ab); ?>;
            const dataDiffBA = <?php echo json_encode($data_diff_ba); ?>;
            const dataOutside = <?php echo json_encode($data_outside); ?>;
            const dataIntersect = <?php echo json_encode($data_intersect); ?>;

            const geomA = <?php echo $geojson_wA; ?>;
            const geomB = <?php echo $geojson_wB; ?>;

            let mapbesar;
            let subMaps = {};
            let subMapLayers = {
                onlyA: L.layerGroup(),
                onlyB: L.layerGroup(),
                union: L.layerGroup(),
                diffAB: L.layerGroup(),
                diffBA: L.layerGroup(),
                outside: L.layerGroup(),
                intersect: L.layerGroup()
            };

            window.onload = function() {
                initMainMap();
                initSubMaps();

                // Dropdown multi-select logic
                const btn = document.getElementById('school-dropdown-btn');
                const menu = document.getElementById('school-dropdown-menu');
                const arrow = document.getElementById('school-dropdown-arrow');

                if (btn && menu) {
                    btn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        menu.classList.toggle('hidden');
                        arrow.classList.toggle('rotate-180');
                    });

                    document.addEventListener('click', function(e) {
                        if (!menu.contains(e.target) && e.target !== btn) {
                            menu.classList.add('hidden');
                            arrow.classList.remove('rotate-180');
                        }
                    });
                }
            };

            function initMainMap() {
                mapbesar = L.map('mapbesar').setView([-6.914744, 108.5], 8);
                L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
                    attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
                }).addTo(mapbesar);

                // Leaflet Draw toolbar configured for POLYGONS only
                const drawnItems = new L.FeatureGroup().addTo(mapbesar);
                const drawControl = new L.Control.Draw({
                    edit: { featureGroup: drawnItems, remove: false, edit: false },
                    draw: {
                        polygon: true,
                        marker: false,
                        polyline: false,
                        rectangle: false,
                        circle: false,
                        circlemarker: false
                    }
                });
                mapbesar.addControl(drawControl);

                // Handle polygon creation event
                mapbesar.on(L.Draw.Event.CREATED, function (e) {
                    const layer = e.layer;
                    const geojson = layer.toGeoJSON().geometry;
                    
                    fetch('index.php?action=save_polygon', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ geojson: geojson })
                    })
                    .then(res => res.json())
                    .then(res => {
                        if (res.status === 'success') {
                            window.location.reload();
                        } else {
                            alert('Gagal menyimpan poligon: ' + res.message);
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert('Terjadi kesalahan koneksi.');
                    });
                });

                // Display all custom user polygons
                const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#06b6d4', '#ec4899', '#8b5cf6'];
                const boundsArr = [];

                semuaPolygons.forEach((item, index) => {
                    const color = colors[index % colors.length];
                    const layer = L.geoJSON(item.geojson, {
                        style: { color: color, weight: 2.5, fillColor: color, fillOpacity: 0.12 }
                    }).addTo(mapbesar);
                    
                    layer.bindTooltip(item.nama, { permanent: true, direction: 'center', className: 'polygon-tooltip' });
                    layer.bindPopup(`<strong>${item.nama}</strong>`);
                    boundsArr.push(layer);
                });

                // Display checked school markers
                selectedSchools.forEach(sch => {
                    const marker = L.marker([sch.lat, sch.lng], { icon: getSchoolIcon(sch.jenjang) }).addTo(mapbesar);
                    marker.bindPopup(`<b>${sch.nama_sekolah} (${sch.jenjang})</b>`);
                });

                if (boundsArr.length > 0) {
                    mapbesar.fitBounds(L.featureGroup(boundsArr).getBounds().pad(0.1));
                }
            }

            function initSubMaps() {
                const subMapIds = {
                    onlyA: 'sub-map-only-a',
                    onlyB: 'sub-map-only-b',
                    union: 'sub-map-union',
                    diffAB: 'sub-map-diff-ab',
                    diffBA: 'sub-map-diff-ba',
                    outside: 'sub-map-outside',
                    intersect: 'sub-map-intersect'
                };

                const datasets = {
                    onlyA: { data: dataOnlyA, color: '#6366f1' },
                    onlyB: { data: dataOnlyB, color: '#10b981' },
                    union: { data: dataUnion, color: '#a855f7' },
                    diffAB: { data: dataDiffAB, color: '#2563eb' },
                    diffBA: { data: dataDiffBA, color: '#ef4444' },
                    outside: { data: dataOutside, color: '#06b6d4', isComplement: true },
                    intersect: { data: dataIntersect, color: '#64748b' }
                };

                for (const key in subMapIds) {
                    // Create standard interactive map (no scroll/drag/zoom lock)
                    subMaps[key] = L.map(subMapIds[key]).setView([-6.914744, 108.5], 8);

                    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {}).addTo(subMaps[key]);
                    subMapLayers[key].addTo(subMaps[key]);

                    const conf = datasets[key];
                    const lg = subMapLayers[key];

                    // 1. Draw outline of Wilayah A and B (reference dotted shapes)
                    const refStyle = { color: '#cbd5e1', weight: 1.5, dashArray: '4, 4', fill: false, interactive: false };
                    if (geomA) L.geoJSON(geomA, { style: refStyle }).addTo(lg);
                    if (geomB) L.geoJSON(geomB, { style: refStyle }).addTo(lg);

                    // 2. Draw calculated spatial overlay shape
                    let mainLayer;
                    if (conf.data.geometry) {
                        mainLayer = L.geoJSON(conf.data.geometry, {
                            style: {
                                color: conf.color,
                                fillColor: conf.color,
                                fillOpacity: conf.isComplement ? 0.05 : 0.25,
                                weight: conf.isComplement ? 1 : 2.5
                            }
                        }).bindPopup(`<strong>Hasil Spasial ${key}</strong>`).addTo(lg);
                    }

                    // 3. Draw schools that are inside overlay region
                    if (conf.data.markers) {
                        conf.data.markers.forEach(m => {
                            const coords = m.geojson.coordinates;
                            // Find the school's jenjang from list to color icon correctly
                            const matchedSch = selectedSchools.find(s => s.nama_sekolah === m.nama);
                            const jenjang = matchedSch ? matchedSch.jenjang : 'SD';
                            L.marker([coords[1], coords[0]], { icon: getSchoolIcon(jenjang) })
                             .bindPopup(`<strong>${m.nama}</strong>`)
                             .addTo(lg);
                        });
                    }

                    // Fit bounds for each submap individually to its geometry
                    if (mainLayer) {
                        try {
                            subMaps[key].fitBounds(mainLayer.getBounds().pad(0.1));
                        } catch(e) {
                            console.warn("Could not fit bounds for submap", key, e);
                        }
                    } else if (geomA || geomB) {
                        const tempGroup = L.featureGroup();
                        if (geomA) L.geoJSON(geomA).addTo(tempGroup);
                        if (geomB) L.geoJSON(geomB).addTo(tempGroup);
                        try {
                            subMaps[key].fitBounds(tempGroup.getBounds().pad(0.1));
                        } catch(e) {}
                    }
                }
            }


    </script>
</body>
</html>